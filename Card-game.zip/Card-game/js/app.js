const gameBox = document.querySelectorAll('.game-box');
const back = document.querySelectorAll('.back p');
const scoreResult = document.querySelector('#score') ;
const moveResult = document.querySelector('#move') ;
let winningResult;
let arr = [1,1,2,2,3,3,4,4];
let moves = 0;
let score = 0;
let sample = [];
gameBox.forEach(el => 
    {
        el.addEventListener('click',function()
        {
            this.classList.add('active');
          sample.push(this)

          if(sample.length == 2)
          {
            if(sample[0].children[1].innerText == sample[1].children[1].innerText)
            {
                score++;
                sample.length = 0;
                scoreResult.innerHTML = score;
            }
            else 
            {
              setTimeout(() => 
              {

                  sample.forEach(removeActive => 
                    {
                        removeActive.classList.remove('active');
                    })
                    sample.length = 0;
                },600)
            // console.log('This is incorrect')
            }
            moves++;
            moveResult.innerHTML = moves
          }
          setTimeout(() => 
          {
            if(checkWin())
          {
             alert("You won the match bro");
             window.location.reload();
          }
        },1500)
        })
})


function checkWin()
{
  let check = [];
  let result = [...gameBox].every(el => 
  {
    return (el.classList.contains('active') == true)
  })
  // return result;

  return result;
}



